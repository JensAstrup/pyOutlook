from .core.main import OutlookAccount

if __name__ == '__main__':
    init = OutlookAccount(None)
    print('pyOutlook ready.')
